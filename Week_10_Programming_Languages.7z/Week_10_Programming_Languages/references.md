Thank you to [Muhammad Khalid and Kaggle](https://www.kaggle.com/datasets/muhammadkhalid/most-popular-programming-languages-since-2004?resource=download) for the data.
